﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PharmacyManagement_WebAPI.Migrations
{
    public partial class MigrationValidation : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
